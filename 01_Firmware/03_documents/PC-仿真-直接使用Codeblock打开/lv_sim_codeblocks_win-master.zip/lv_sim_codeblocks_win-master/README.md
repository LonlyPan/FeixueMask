# pc_simulator_win_codeblocks
PC simulator project for LittlevGL embedded GUI Library for Windows in Codeblocks

This requires the MinGW version of **CodeBlocks 20.03 or newer** to be installed.

## To use

1. Clone this repository making sure to also update submodules.
2. Open `LittlevGL.cbp` in CodeBlocks.
3. Build and run the project.
