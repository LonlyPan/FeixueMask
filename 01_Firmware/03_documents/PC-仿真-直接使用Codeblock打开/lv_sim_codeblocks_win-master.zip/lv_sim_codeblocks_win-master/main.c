
/**
 * @file main
 *
 */

/*********************
 *      INCLUDES
 *********************/
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include "lvgl/lvgl.h"
#include "lv_drivers/win_drv.h"
#include "lv_examples/src/lv_demo_widgets/lv_demo_widgets.h"

#include <windows.h>


/*********************
 *      DEFINES
 *********************/
double sine_taylor(double x)
{
	if(x>90 && x <= 180)
		x = 180 - x;
    else if(x>180 && x <= 270)
		x = 180 - x;
	else if(x>270 && x <= 360)
		x = x - 360;

    x = x * 2*3.14 / 360.0;
    // useful to pre-calculate
    double x2 = x*x;
    double x4 = x2*x2;

    // Calculate the terms
    // As long as abs(x) < sqrt(6), which is 2.45, all terms will be positive.
    // Values outside this range should be reduced to [-pi/2, pi/2] anyway for accuracy.
    // Some care has to be given to the factorials.
    // They can be pre-calculated by the compiler,
    // but the value for the higher ones will exceed the storage capacity of int.
    // so force the compiler to use unsigned long longs (if available) or doubles.
    double t1 = x * (1.0 - x2 / (2*3));
    double x5 = x * x4;
    double t2 = x5 * (1.0 - x2 / (6*7)) / (1.0* 2*3*4*5);
    double x9 = x5 * x4;
    double t3 = x9 * (1.0 - x2 / (10*11)) / (1.0* 2*3*4*5*6*7*8*9);
    double x13 = x9 * x4;
    double t4 = x13 * (1.0 - x2 / (14*15)) / (1.0* 2*3*4*5*6*7*8*9*10*11*12*13);
    // add some more if your accuracy requires them.
    // But remember that x is smaller than 2, and the factorial grows very fast
    // so I doubt that 2^17 / 17! will add anything.
    // Even t4 might already be too small to matter when compared with t1.

    // Sum backwards
    double result = t4;
    result += t3;
    result += t2;
    result += t1;

    return result;
}

double cose_taylor(double x)
{

    const float Q = 90; // pi/2
    const float PI =180;
    x += Q;

    if(x > PI)
        x -= 2 * PI;

    return( sine_taylor(x));
}

/**********************
 *      TYPEDEFS
 **********************/

/**********************
 *  STATIC PROTOTYPES
 **********************/
static void hal_init(void);
static int tick_thread(void *data);

/**********************
 *  STATIC VARIABLES
 **********************/

/**********************
 *      MACROS
 **********************/


static lv_style_t arc_block_style;
static lv_style_t arc_line_style;

lv_obj_t * big_arc; // ��Ļ��λ���
lv_obj_t * tiny_arc;// С�Ļ��λ���
lv_obj_t * out_arc; // �⻡��
lv_obj_t * in_arc1;  // �ڻ���
lv_obj_t * in_arc2;

lv_obj_t * line1;
lv_obj_t * line2;
lv_obj_t * line3;
lv_obj_t * line4;
lv_obj_t * scr11;
lv_obj_t * scr12;

static lv_point_t line_points[2] = {{0,0},{0,0}};
static int line_angle= 87;

static lv_point_t line_points2[2] = {{0,0},{0,0}};
static int line2_angle_offest = 51;

static lv_point_t line_points3[2] = {{0,0},{0,0}};
static int line3_angle_offest = 80;

static lv_point_t line_points4[2] = {{0,0},{0,0}};
static int line4_angle_offest = -33;


/* ��Բ������ʼ�� */
static int16_t big_arc_block_start_angle = 330;
static int16_t big_arc_block_offer = 300;

static int16_t tiny_arc_block_start_angle = 125;
static int16_t tiny_arc_block_end_angle = 25;

static int16_t out_arc_block_start_angle = 285;
static int16_t out_arc_block_off = 265;

static int16_t in_arc1_block_start_angle = 305;
static int16_t in_arc1_block_offer = 110;

static int16_t in_arc2_block_start_angle = 220;
static int16_t in_arc2_block_offer = 55;



#define MAIN_COLOR lv_color_make(255, 240,70)   //255, 255,74
//static lv_style_t lmeter_style;
/**
 * An `lv_task` to call periodically to set the angles of the arc
 * @param t
 */

static uint32_t fps_cnt = 0;
static uint32_t arc_size_reduce = 0;


lv_obj_t *show_scr1;
lv_obj_t *show_scr3;
lv_obj_t *show_scr4;
lv_obj_t *scr1_label;
lv_obj_t *show_scr2;
lv_task_t * scr1_task;


uint32_t buf_show = 0;
static char buf[30];//���渡����ת������ַ�
static bool scr1_task_flag = true;

static void rest_show_scr1()
{
    lv_obj_set_style_local_line_opa(big_arc,LV_ARC_PART_INDIC,LV_STATE_DEFAULT,255);
    lv_obj_set_style_local_line_opa(tiny_arc,LV_ARC_PART_INDIC,LV_STATE_DEFAULT,255);
    lv_obj_set_style_local_line_opa(in_arc1,LV_ARC_PART_INDIC,LV_STATE_DEFAULT,255);
    lv_obj_set_style_local_line_opa(in_arc2,LV_ARC_PART_INDIC,LV_STATE_DEFAULT,255);
    lv_obj_set_style_local_line_opa(out_arc,LV_ARC_PART_INDIC,LV_STATE_DEFAULT,255);

    lv_style_set_line_width(&arc_line_style, LV_STATE_DEFAULT,7);

    lv_arc_set_angles(big_arc,big_arc_block_start_angle,big_arc_block_start_angle-big_arc_block_offer);
    lv_arc_set_angles(tiny_arc, tiny_arc_block_start_angle,150);
    lv_arc_set_angles(in_arc1, in_arc1_block_start_angle,in_arc1_block_start_angle-in_arc1_block_offer);
    lv_arc_set_angles(in_arc2, in_arc2_block_start_angle,in_arc2_block_start_angle+in_arc2_block_offer);
    lv_arc_set_angles(out_arc, out_arc_block_start_angle-out_arc_block_off,out_arc_block_start_angle);

    lv_obj_set_size(in_arc1, 174, 174);
    lv_obj_set_size(in_arc2, 174, 174);
    lv_obj_set_size(tiny_arc, 240, 240);
    //lv_obj_set_size(in_arc2, 240, 240);

    lv_obj_align(in_arc1, show_scr1, LV_ALIGN_CENTER, 0, 0);
    lv_obj_align(in_arc2, show_scr1, LV_ALIGN_CENTER, 0, 0);
    lv_obj_align(tiny_arc, show_scr1, LV_ALIGN_CENTER, 0, 0);
    //*
    line_points[0].x= (int)(120+80*cose_taylor(line_angle));
    line_points[0].y =(int)(120-80*sine_taylor(line_angle));

    line_points[1].x= (int)(120+116*cose_taylor(line_angle));
    line_points[1].y = (int)(120-116*sine_taylor(line_angle));


    line_points2[0].x= (int)(120+80*cose_taylor(line_angle+line2_angle_offest));
    line_points2[0].y =(int)(120-80*sine_taylor(line_angle+line2_angle_offest));

    line_points2[1].x= (int)(120+116*cose_taylor(line_angle+line2_angle_offest));
    line_points2[1].y = (int)(120-116*sine_taylor(line_angle+line2_angle_offest));


    line_points3[0].x= (int)(120+80*cose_taylor(line_angle+line3_angle_offest));
    line_points3[0].y =(int)(120-80*sine_taylor(line_angle+line3_angle_offest));

    line_points3[1].x= (int)(120+116*cose_taylor(line_angle+line3_angle_offest));
    line_points3[1].y = (int)(120-116*sine_taylor(line_angle+line3_angle_offest));


    line_points4[0].x= (int)(120+80*cose_taylor(line_angle+line4_angle_offest));
    line_points4[0].y =(int)(120-80*sine_taylor(line_angle+line4_angle_offest));

    line_points4[1].x= (int)(120+116*cose_taylor(line_angle+line4_angle_offest));
    line_points4[1].y = (int)(120-116*sine_taylor(line_angle+line4_angle_offest));

    lv_obj_set_style_local_line_opa(line1,LV_LINE_PART_MAIN,LV_STATE_DEFAULT,255);
    lv_obj_set_style_local_line_opa(line2,LV_LINE_PART_MAIN,LV_STATE_DEFAULT,255);
    lv_obj_set_style_local_line_opa(line3,LV_LINE_PART_MAIN,LV_STATE_DEFAULT,255);
    lv_obj_set_style_local_line_opa(line4,LV_LINE_PART_MAIN,LV_STATE_DEFAULT,255);

    lv_line_set_points(line2, line_points2,2);
    lv_line_set_points(line1, line_points,2);

    lv_line_set_points(line3, line_points3,2);
    lv_line_set_points(line4, line_points4,2);


}
static void show_scr1_loader(lv_task_t * t)
{

    sprintf(buf, "%d", buf_show++);//��dataת��Ϊfmt��ʽ���ַ�
    lv_label_set_text(scr1_label,buf);
    //lv_obj_align(label1, NULL, LV_ALIGN_CENTER, 0, 0);

	static opa_temp = 0;

	if(scr1_task_flag ){
        big_arc_block_start_angle -= 1;
        tiny_arc_block_start_angle -= 1;
        in_arc1_block_start_angle -= 1;
        in_arc2_block_start_angle -= 1;
        line_angle += 1;

        lv_arc_set_angles(big_arc, big_arc_block_start_angle,(big_arc_block_start_angle < big_arc_block_offer)? big_arc_block_start_angle+60:big_arc_block_start_angle - big_arc_block_offer);
        lv_arc_set_angles(tiny_arc, tiny_arc_block_start_angle < 0 ? (360+tiny_arc_block_start_angle):tiny_arc_block_start_angle ,tiny_arc_block_start_angle+tiny_arc_block_end_angle);

        if(big_arc_block_start_angle > 200) {
                lv_arc_set_angles(in_arc1, in_arc1_block_start_angle,in_arc1_block_start_angle-in_arc1_block_offer);
                lv_arc_set_angles(in_arc2, in_arc2_block_start_angle,in_arc2_block_start_angle+in_arc2_block_offer);
        }
        //*
        line_points[0].x= (int)(120+80*cose_taylor(line_angle));
        line_points[0].y =(int)(120-80*sine_taylor(line_angle));

        line_points[1].x= (int)(120+116*cose_taylor(line_angle));
        line_points[1].y = (int)(120-116*sine_taylor(line_angle));


        line_points2[0].x= (int)(120+80*cose_taylor(line_angle+line2_angle_offest));
        line_points2[0].y =(int)(120-80*sine_taylor(line_angle+line2_angle_offest));

        line_points2[1].x= (int)(120+116*cose_taylor(line_angle+line2_angle_offest));
        line_points2[1].y = (int)(120-116*sine_taylor(line_angle+line2_angle_offest));


        line_points3[0].x= (int)(120+80*cose_taylor(line_angle+line3_angle_offest));
        line_points3[0].y =(int)(120-80*sine_taylor(line_angle+line3_angle_offest));

        line_points3[1].x= (int)(120+116*cose_taylor(line_angle+line3_angle_offest));
        line_points3[1].y = (int)(120-116*sine_taylor(line_angle+line3_angle_offest));


        line_points4[0].x= (int)(120+80*cose_taylor(line_angle+line4_angle_offest));
        line_points4[0].y =(int)(120-80*sine_taylor(line_angle+line4_angle_offest));

        line_points4[1].x= (int)(120+116*cose_taylor(line_angle+line4_angle_offest));
        line_points4[1].y = (int)(120-116*sine_taylor(line_angle+line4_angle_offest));


        lv_line_set_points(line2, line_points2,2);
        lv_line_set_points(line1, line_points,2);

        lv_line_set_points(line3, line_points3,2);
        lv_line_set_points(line4, line_points4,2);


        if(big_arc_block_start_angle <= 145) { // ��һ�α䰵2������
            lv_arc_set_angles(in_arc1,0,0);
            line_angle= 87;
            big_arc_block_start_angle = 330;
            tiny_arc_block_start_angle = 125;
            out_arc_block_start_angle = 285;
            in_arc1_block_start_angle = 305;
            in_arc2_block_start_angle = 220;
            //lv_arc_set_angles(in_arc1,0,0);
            scr1_task_flag = false;
        }

        else if(big_arc_block_start_angle <= 155) { // ��һ�α䰵2������

            arc_size_reduce = 169;
            lv_arc_set_angles(in_arc1,0,359);
            lv_style_set_line_width(&arc_line_style, LV_STATE_DEFAULT,4);
            lv_obj_set_size(in_arc1, 174-arc_size_reduce, 174-arc_size_reduce);
            lv_obj_set_style_local_line_opa(in_arc1,LV_ARC_PART_INDIC,LV_STATE_DEFAULT,80);
            lv_obj_align(in_arc1, NULL, LV_ALIGN_CENTER, 0, 0);

        }

        else if(big_arc_block_start_angle <= 165) { // ��һ�α䰵2������

            arc_size_reduce = 150;
            lv_arc_set_start_angle(in_arc1,in_arc1_block_start_angle+110);
            lv_obj_set_size(in_arc1, 174-arc_size_reduce, 174-arc_size_reduce);
            lv_obj_set_style_local_line_opa(in_arc1,LV_ARC_PART_INDIC,LV_STATE_DEFAULT,80);
            lv_obj_align(in_arc1, NULL, LV_ALIGN_CENTER, 0, 0);

        }
        else if(big_arc_block_start_angle <= 175) { // ��һ�α䰵2������
            lv_arc_set_angles(out_arc,0,0);

            arc_size_reduce = 130;

            lv_arc_set_start_angle(in_arc1,in_arc1_block_start_angle+80);
            lv_obj_set_size(in_arc1, 174-arc_size_reduce, 174-arc_size_reduce);
            lv_obj_set_style_local_line_opa(in_arc1,LV_ARC_PART_INDIC,LV_STATE_DEFAULT,150);

            lv_obj_align(in_arc1, NULL, LV_ALIGN_CENTER, 0, 0);

        }
        else if(big_arc_block_start_angle <= 180) { // ��һ�α䰵2������
            lv_arc_set_end_angle(out_arc,40);

            arc_size_reduce = 90;

            lv_obj_set_size(in_arc1, 174-arc_size_reduce, 174-arc_size_reduce);
            lv_obj_align(in_arc1, NULL, LV_ALIGN_CENTER, 0, 0);
        }

        else if(big_arc_block_start_angle <= 190) { // ��һ�α䰵2������
            lv_obj_set_style_local_line_opa(tiny_arc,LV_ARC_PART_INDIC,LV_STATE_DEFAULT,0);
            lv_arc_set_end_angle(out_arc,out_arc_block_start_angle-195);
            lv_arc_set_angles(in_arc2, 0,0);

            arc_size_reduce = 60;
            lv_obj_set_size(in_arc1, 174-arc_size_reduce, 174-arc_size_reduce);
            lv_obj_align(in_arc1, NULL, LV_ALIGN_CENTER, 0, 0);
            lv_obj_align(tiny_arc, NULL, LV_ALIGN_CENTER, 0, 0);

        }

        else if(big_arc_block_start_angle <= 195) { // ��һ�α䰵2������
            lv_obj_set_style_local_line_opa(tiny_arc,LV_ARC_PART_INDIC,LV_STATE_DEFAULT,30);
            lv_arc_set_end_angle(out_arc,out_arc_block_start_angle-135);
            lv_arc_set_start_angle(in_arc2,in_arc2_block_start_angle+in_arc2_block_offer-20);

            arc_size_reduce = 30;
            lv_obj_set_size(in_arc1, 174-arc_size_reduce, 174-arc_size_reduce);
            lv_obj_set_size(in_arc2, 174-arc_size_reduce, 174-arc_size_reduce);
            lv_obj_set_size(tiny_arc, 240-arc_size_reduce, 240-arc_size_reduce);

            lv_obj_align(in_arc1, NULL, LV_ALIGN_CENTER, 0, 0);
            lv_obj_align(in_arc2, NULL, LV_ALIGN_CENTER, 0, 0);
            lv_obj_align(tiny_arc, NULL, LV_ALIGN_CENTER, 0, 0);


        }
        else if(big_arc_block_start_angle <= 200) { // ��һ�α䰵2������
            lv_obj_set_style_local_line_opa(tiny_arc,LV_ARC_PART_INDIC,LV_STATE_DEFAULT,100);
            lv_arc_set_end_angle(out_arc,out_arc_block_start_angle-95);
            arc_size_reduce = 10;
            lv_obj_set_size(in_arc1, 174-arc_size_reduce, 174-arc_size_reduce);
            lv_obj_set_size(in_arc2, 174-arc_size_reduce, 174-arc_size_reduce);
            lv_obj_set_size(tiny_arc, 240-arc_size_reduce, 240-arc_size_reduce);
            lv_obj_align(in_arc1, NULL, LV_ALIGN_CENTER, 0, 0);
            lv_obj_align(in_arc2, NULL, LV_ALIGN_CENTER, 0, 0);
            lv_obj_align(tiny_arc, NULL, LV_ALIGN_CENTER, 0, 0);
        }
        else if(big_arc_block_start_angle <= 203) { // ��һ�α䰵2������
            lv_arc_set_end_angle(out_arc,out_arc_block_start_angle-60);

        }
        else if(big_arc_block_start_angle <= 206) { // ��һ�α䰵2������
            lv_obj_set_style_local_line_opa(tiny_arc,LV_ARC_PART_INDIC,LV_STATE_DEFAULT,255);
            lv_obj_set_style_local_line_opa(line4,LV_LINE_PART_MAIN,LV_STATE_DEFAULT,0);
            lv_arc_set_end_angle(out_arc,out_arc_block_start_angle-35);

        }
        else if(big_arc_block_start_angle <= 209) { // ��һ�α䰵2������
            lv_obj_set_style_local_line_opa(tiny_arc,LV_ARC_PART_INDIC,LV_STATE_DEFAULT,50);
            lv_obj_set_style_local_line_opa(line4,LV_LINE_PART_MAIN,LV_STATE_DEFAULT,50);
            lv_arc_set_end_angle(out_arc,out_arc_block_start_angle-15);
        }
        else if(big_arc_block_start_angle <= 214) { // ��һ�α䰵2������
            lv_obj_set_style_local_line_opa(tiny_arc,LV_ARC_PART_INDIC,LV_STATE_DEFAULT,240);
            lv_obj_set_style_local_line_opa(line4,LV_LINE_PART_MAIN,LV_STATE_DEFAULT,150);
            lv_arc_set_end_angle(out_arc,out_arc_block_start_angle-5);
        }
        else if(big_arc_block_start_angle <= 360 -138) { // ��һ�α䰵2������
            lv_obj_set_style_local_line_opa(big_arc,LV_ARC_PART_INDIC,LV_STATE_DEFAULT,0);
            lv_obj_set_style_local_line_opa(line2,LV_LINE_PART_MAIN,LV_STATE_DEFAULT,0);
        }
        else if(big_arc_block_start_angle <= 360 -135) { // ��һ�α䰵2������
            lv_obj_set_style_local_line_opa(big_arc,LV_ARC_PART_INDIC,LV_STATE_DEFAULT,200);
            lv_obj_set_style_local_line_opa(line4,LV_LINE_PART_MAIN,LV_STATE_DEFAULT,255);
            lv_obj_set_style_local_line_opa(line2,LV_LINE_PART_MAIN,LV_STATE_DEFAULT,150);
        }
        else if(big_arc_block_start_angle <= 360 -132) { // ��һ�α䰵2������
            lv_obj_set_style_local_line_opa(big_arc,LV_ARC_PART_INDIC,LV_STATE_DEFAULT,255);
            lv_obj_set_style_local_line_opa(line4,LV_LINE_PART_MAIN,LV_STATE_DEFAULT,0);
            lv_obj_set_style_local_line_opa(line2,LV_LINE_PART_MAIN,LV_STATE_DEFAULT,255);
        }
        else if(big_arc_block_start_angle <= 360 -128) { // ��һ�α䰵2������
            lv_obj_set_style_local_line_opa(big_arc,LV_ARC_PART_INDIC,LV_STATE_DEFAULT,120);
            lv_obj_set_style_local_line_opa(line1,LV_LINE_PART_MAIN,LV_STATE_DEFAULT,0);
            lv_obj_set_style_local_line_opa(line2,LV_LINE_PART_MAIN,LV_STATE_DEFAULT,0);
        }
        else if(big_arc_block_start_angle <= 360 -125) {  // ��һ�α䰵1��ǳ��
            lv_obj_set_style_local_line_opa(big_arc,LV_ARC_PART_INDIC,LV_STATE_DEFAULT,200);
            lv_obj_set_style_local_line_opa(line1,LV_LINE_PART_MAIN,LV_STATE_DEFAULT,150);
            lv_obj_set_style_local_line_opa(line2,LV_LINE_PART_MAIN,LV_STATE_DEFAULT,150);
        }
        else if(big_arc_block_start_angle <= 360 -123) {  //
            lv_obj_set_style_local_line_opa(line1,LV_LINE_PART_MAIN,LV_STATE_DEFAULT,255);
        }
        else if(big_arc_block_start_angle <= 360 -118) {  //
            lv_obj_set_style_local_line_opa(line1,LV_LINE_PART_MAIN,LV_STATE_DEFAULT,0);
             lv_obj_set_style_local_line_opa(line3,LV_LINE_PART_MAIN,LV_STATE_DEFAULT,0);
        }
        else if(big_arc_block_start_angle <= 360 -115) {  //
            lv_obj_set_style_local_line_opa(line1,LV_LINE_PART_MAIN,LV_STATE_DEFAULT,150);
            lv_obj_set_style_local_line_opa(line3,LV_LINE_PART_MAIN,LV_STATE_DEFAULT,150);
        }
        else if(big_arc_block_start_angle <= 360 -110) {  //
            lv_obj_set_style_local_line_opa(line3,LV_LINE_PART_MAIN,LV_STATE_DEFAULT,0);
        }
        else if(big_arc_block_start_angle <= 360 -102) {  //
            lv_obj_set_style_local_line_opa(line3,LV_LINE_PART_MAIN,LV_STATE_DEFAULT,150);
        }
        //*/
	}
}

void test_screen()
{
/* ������䱳��ɫ,Ŀǰû�ҵ���䱳���ĺ���,ʹ��û�нǶ�ֵ��Բ���ռ���� */

    /* scr1 ��ʽ�� */
    // ���λ���ʽ�����ڻ��λ���
    lv_style_init(&arc_block_style);
    lv_style_set_line_width(&arc_block_style, LV_STATE_DEFAULT,40);         /* ���û��λ����� */
    lv_style_set_line_rounded(&arc_block_style, LV_STATE_DEFAULT,false);    /* ��������Ϊֱ�� */
    lv_style_set_pad_all(&arc_block_style, LV_STATE_DEFAULT,0);             /* �����ڲ������ ������ʾ���������֮��ľ��� */

    lv_style_set_line_color(&arc_block_style,LV_STATE_DEFAULT,MAIN_COLOR);  /* ���� ������ʾ������ɫ */
    lv_style_set_bg_opa(&arc_block_style,LV_STATE_DEFAULT,0);               /* ������ʾ����͸�� */
    lv_style_set_border_opa(&arc_block_style,LV_STATE_DEFAULT,0);               /* ������ʾ����͸�� */

    // ����������ʽ�����䣬�������⻷��
    lv_style_init(&arc_line_style);
    lv_style_set_line_width(&arc_line_style, LV_STATE_DEFAULT,7);           /* ���û��λ����� */

    /* �������߶���ʽ */
    static lv_style_t style_line;
    lv_style_init(&style_line);
    lv_style_set_line_width(&style_line, LV_STATE_DEFAULT, 7);
    lv_style_set_line_rounded(&style_line, LV_STATE_DEFAULT,false);    /* ��������Ϊֱ�� */
    lv_style_set_line_color(&style_line, LV_STATE_DEFAULT, MAIN_COLOR);

    /* ����1 */
    show_scr1 = lv_scr_act();//lv_obj_create(lv_scr_act(), NULL);    /* ���ȴ���һ��Ĭ�Ͻ��棬����̳е�ǰĬ����Ļ */

    lv_obj_t * scr1_backgroud = lv_obj_create(show_scr1, NULL);     /* �������� */
    lv_obj_set_style_local_bg_color(scr1_backgroud ,LV_OBJ_PART_MAIN,LV_STATE_DEFAULT,lv_color_make(1, 1,1));  /* ���ñ���������ɫ����ɫ */
    lv_obj_set_style_local_border_color(scr1_backgroud ,LV_OBJ_PART_MAIN,LV_STATE_DEFAULT,lv_color_make(1, 1,1));
    lv_obj_set_size(scr1_backgroud, 240,240);                   /* ���ñ�����С */
    lv_obj_align(scr1_backgroud, show_scr1, LV_ALIGN_CENTER, 0, 0); /* ���ñ������scrλ�� */

    scr1_label = lv_label_create(scr1_backgroud, NULL);    /* ����label�������ڱ�ʶ����ʽӦ�û�ɾ�� */
    lv_label_set_text(scr1_label, "Screen 1");
    lv_obj_align(scr1_label, show_scr1, LV_ALIGN_CENTER, 0, 0);


    /*�ϴ�Ļ��λ���*/
    big_arc = lv_arc_create(show_scr1, NULL);
    lv_obj_add_style(big_arc ,LV_ARC_PART_INDIC, &arc_block_style);         /* ���û�����ʾ������ʽ  */
    lv_obj_add_style(big_arc ,LV_ARC_PART_BG, &arc_block_style);            /* ���ñ���������ʽ*/
    lv_arc_set_bg_angles(big_arc,0,0);                                      /* ���ñ������νǶ�Ϊ0������ʾ  */
    lv_arc_set_angles(big_arc,big_arc_block_start_angle,big_arc_block_start_angle-big_arc_block_offer);                                     /* ����ǰ�����νǶ�Ϊ */
    lv_obj_set_size(big_arc, 240, 240);                                     /* ���ö�����Ļ����С */
    lv_obj_align(big_arc, show_scr1, LV_ALIGN_CENTER, 0, 0);                     /* ���ö���λ�ã����У�ƫ��0*/

    /*��С�Ļ��λ���*/
    tiny_arc = lv_arc_create(show_scr1,big_arc);              /* �̳� big_arc ��ʽ */
    lv_arc_set_bg_angles(tiny_arc,0,0);
    lv_arc_set_angles(tiny_arc, tiny_arc_block_start_angle,150);
    lv_obj_set_size(tiny_arc, 240, 240);
    lv_obj_align(tiny_arc, show_scr1, LV_ALIGN_CENTER, 0, 0);
    //lv_task_create(tiny_arc_loader, 1000, LV_TASK_PRIO_LOWEST, tiny_arc);

    /*out block Arc*/
    out_arc = lv_arc_create(show_scr1,big_arc);
    lv_obj_add_style(out_arc,_LV_OBJ_PART_VIRTUAL_LAST, &arc_line_style);   /* ���޸Ĳ�����ʽ ǰ�������� */
    lv_arc_set_bg_angles(out_arc,0,0);
    lv_arc_set_angles(out_arc, out_arc_block_start_angle-out_arc_block_off,out_arc_block_start_angle);
    lv_obj_set_size(out_arc, 240, 240);
    lv_obj_align(out_arc, show_scr1, LV_ALIGN_CENTER, 0, 0);

    /*in block Arc1*/
    in_arc1 = lv_arc_create(show_scr1,out_arc);                /* �̳� out_arc ��ʽ */
    lv_obj_set_style_local_border_opa(in_arc1,LV_OBJ_PART_MAIN,LV_STATE_DEFAULT,0);  /* �߿�͸�� */

    lv_arc_set_bg_angles(in_arc1,0,0);
    lv_arc_set_angles(in_arc1, in_arc1_block_start_angle,in_arc1_block_start_angle-in_arc1_block_offer);
    lv_obj_set_size(in_arc1, 174, 174);                                      /* С�Ļ������ڲ��������СҪ�䣬��ȥ���߿� */
    lv_obj_align(in_arc1, show_scr1, LV_ALIGN_CENTER, 0, 0);

    /*in block Arc2*/
    in_arc2 = lv_arc_create(show_scr1,in_arc1);                /* �̳� out_arc ��ʽ */
    lv_arc_set_angles(in_arc2, in_arc2_block_start_angle,in_arc2_block_start_angle+in_arc2_block_offer);
    lv_obj_set_size(in_arc2, 174, 174);                                      /* С�Ļ������ڲ��������СҪ�䣬��ȥ���߿� */
    lv_obj_align(in_arc2, show_scr1, LV_ALIGN_CENTER, 0, 0);

    /*Create a line meter */
    line_points[0].x= (int)(120+80*cose_taylor(line_angle));
    line_points[0].y =(int)(120-80*sine_taylor(line_angle));
    line_points[1].x= (int)(120+116*cose_taylor(line_angle));
    line_points[1].y = (int)(120-116*sine_taylor(line_angle));

    /*Create a line and apply the new style*/
    line1 = lv_line_create(show_scr1, NULL);
    lv_obj_add_style(line1, LV_LINE_PART_MAIN, &style_line);     /*Set the points*/
    lv_line_set_points(line1, line_points,2);     /*Set the points*/


    line_points2[0].x= (int)(120+80*cose_taylor(line_angle+line2_angle_offest));
    line_points2[0].y =(int)(120-80*sine_taylor(line_angle+line2_angle_offest));

    line_points2[1].x= (int)(120+116*cose_taylor(line_angle+line2_angle_offest));
    line_points2[1].y = (int)(120-116*sine_taylor(line_angle+line2_angle_offest));


    line2 = lv_line_create(show_scr1, line1);
    lv_line_set_points(line2, line_points2,2);     /*Set the points*/

    line_points3[0].x= (int)(120+80*cose_taylor(line_angle+line3_angle_offest));
    line_points3[0].y =(int)(120-80*sine_taylor(line_angle+line3_angle_offest));

    line_points3[1].x= (int)(120+116*cose_taylor(line_angle+line3_angle_offest));
    line_points3[1].y = (int)(120-116*sine_taylor(line_angle+line3_angle_offest));


    line3 = lv_line_create(show_scr1, line1);
    lv_line_set_points(line3, line_points3,2);     /*Set the points*/


    line_points4[0].x= (int)(120+80*cose_taylor(line_angle+line4_angle_offest));
    line_points4[0].y =(int)(120-80*sine_taylor(line_angle+line4_angle_offest));

    line_points4[1].x= (int)(120+116*cose_taylor(line_angle+line4_angle_offest));
    line_points4[1].y = (int)(120-116*sine_taylor(line_angle+line4_angle_offest));


    line4 = lv_line_create(show_scr1, line1);
    lv_line_set_points(line4, line_points4,2);     /*Set the points*/

    scr1_task = lv_task_create(show_scr1_loader, 10,LV_TASK_PRIO_LOW, scr1_backgroud);

    /* ����2 */
    // ���λ���ʽ�����ڻ��λ���
    static lv_style_t scr2_arc2_style;
    lv_style_init(&scr2_arc2_style);
    lv_style_set_line_width(&scr2_arc2_style, LV_STATE_DEFAULT,15);         /* ���û��λ����� */
    lv_style_set_line_rounded(&scr2_arc2_style, LV_STATE_DEFAULT,false);    /* ��������Ϊֱ�� */
    lv_style_set_pad_all(&scr2_arc2_style, LV_STATE_DEFAULT,0);             /* �����ڲ������ ������ʾ���������֮��ľ��� */

    lv_style_set_line_color(&scr2_arc2_style,LV_STATE_DEFAULT,MAIN_COLOR);  /* ���� ������ʾ������ɫ */
    lv_style_set_bg_opa(&scr2_arc2_style,LV_STATE_DEFAULT,0);               /* ������ʾ����͸�� */
    lv_style_set_border_opa(&scr2_arc2_style,LV_STATE_DEFAULT,0);               /* ������ʾ����͸�� */


    show_scr2 = lv_obj_create(NULL, NULL);            /* �ӵڶ������濪ʼ�������´�����Ļ�����ɴӵ�ǰ��Ļ�̳� */

    lv_obj_t * scr2_backgroud = lv_obj_create(show_scr2, NULL);     /* �������� ͬһ�ؼ��ǿ��Թ��õ�,Ҳ�������´���,���������ڴ�*/
    lv_obj_set_style_local_bg_color(scr2_backgroud,LV_OBJ_PART_MAIN,LV_STATE_DEFAULT,lv_color_make(1, 1,1));  /* ���ñ���������ɫ����ɫ */
    lv_obj_set_style_local_border_color(scr2_backgroud,LV_OBJ_PART_MAIN,LV_STATE_DEFAULT,lv_color_make(1,1,1));
    lv_obj_set_size(scr2_backgroud, 240,240);
    lv_obj_align(scr2_backgroud, show_scr2, LV_ALIGN_CENTER, 0, 0);

    lv_obj_t *scr2_arc = lv_arc_create(show_scr2,NULL);
    lv_obj_add_style(scr2_arc  ,LV_ARC_PART_INDIC, &scr2_arc2_style);         /* ���û�����ʾ������ʽ  */
    lv_obj_add_style(scr2_arc  ,LV_ARC_PART_BG, &scr2_arc2_style);            /* ���ñ���������ʽ*/

    lv_arc_set_bg_angles(scr2_arc ,0,0);
    lv_arc_set_angles(scr2_arc , 0,360);
    lv_obj_set_size(scr2_arc , 120, 120);
    lv_obj_align(scr2_arc , show_scr2, LV_ALIGN_CENTER, 0, 0);

    /* ����3 */
    // ���λ���ʽ�����ڻ��λ���
    static lv_style_t scr3_arc_style;
    lv_style_init(&scr3_arc_style);
    lv_style_set_line_width(&scr3_arc_style, LV_STATE_DEFAULT,60);         /* ���û��λ����� */
    lv_style_set_line_rounded(&scr3_arc_style, LV_STATE_DEFAULT,false);    /* ��������Ϊֱ�� */
    lv_style_set_pad_all(&scr3_arc_style, LV_STATE_DEFAULT,0);             /* �����ڲ������ ������ʾ���������֮��ľ��� */

    lv_style_set_line_color(&scr3_arc_style,LV_STATE_DEFAULT,MAIN_COLOR);  /* ���� ������ʾ������ɫ */
    lv_style_set_bg_opa(&scr3_arc_style,LV_STATE_DEFAULT,0);               /* ������ʾ����͸�� */
    lv_style_set_border_opa(&scr3_arc_style,LV_STATE_DEFAULT,0);               /* ������ʾ����͸�� */


    show_scr3 = lv_obj_create(NULL, NULL);            /* �ӵڶ������濪ʼ�������´�����Ļ�����ɴӵ�ǰ��Ļ�̳� */

    lv_obj_t * scr3_backgroud = lv_obj_create(show_scr3, NULL);     /* �������� ͬһ�ؼ��ǿ��Թ��õ�,Ҳ�������´���,���������ڴ�*/
    lv_obj_set_style_local_bg_color(scr3_backgroud,LV_OBJ_PART_MAIN,LV_STATE_DEFAULT,lv_color_make(1, 1,1));  /* ���ñ���������ɫ����ɫ */
    lv_obj_set_style_local_border_color(scr3_backgroud,LV_OBJ_PART_MAIN,LV_STATE_DEFAULT,lv_color_make(1,1,1));
    lv_obj_set_size(scr3_backgroud, 240,240);
    lv_obj_align(scr3_backgroud, show_scr3, LV_ALIGN_CENTER, 0, 0);

    lv_obj_t *scr3_arc = lv_arc_create(show_scr3,NULL);
    lv_obj_add_style(scr3_arc  ,LV_ARC_PART_INDIC, &scr3_arc_style);         /* ���û�����ʾ������ʽ  */
    lv_obj_add_style(scr3_arc  ,LV_ARC_PART_BG, &scr3_arc_style);            /* ���ñ���������ʽ*/
    lv_obj_set_style_local_line_opa(scr3_arc,LV_ARC_PART_INDIC,LV_STATE_DEFAULT,20);
    lv_obj_set_style_local_line_color(scr3_arc,LV_ARC_PART_INDIC,LV_STATE_DEFAULT,lv_color_make(255, 0,250));
    lv_obj_set_style_local_line_width(scr3_arc,LV_ARC_PART_INDIC,LV_STATE_DEFAULT,45);         /* ���û��λ����� */

    lv_arc_set_bg_angles(scr3_arc ,0,0);
    lv_arc_set_angles(scr3_arc , 0,360);
    lv_obj_set_size(scr3_arc , 210, 210);
    lv_obj_align(scr3_arc , show_scr3, LV_ALIGN_CENTER, 0, 0);

    lv_obj_t *scr3_arc3 = lv_arc_create(show_scr3,scr3_arc);
    lv_obj_set_style_local_line_opa(scr3_arc3,LV_ARC_PART_INDIC,LV_STATE_DEFAULT,180);
    lv_obj_set_style_local_line_width(scr3_arc3,LV_ARC_PART_INDIC,LV_STATE_DEFAULT,15);         /* ���û��λ����� */
    lv_obj_set_style_local_line_color(scr3_arc3,LV_ARC_PART_INDIC,LV_STATE_DEFAULT,MAIN_COLOR);

    lv_obj_set_size(scr3_arc3 , 240, 240);
    lv_obj_align(scr3_arc3 , show_scr3, LV_ALIGN_CENTER, 0, 0);

    lv_obj_t *scr3_arc2 = lv_arc_create(show_scr3,scr3_arc);
    lv_obj_set_style_local_line_opa(scr3_arc2,LV_ARC_PART_INDIC,LV_STATE_DEFAULT,60);
    lv_obj_set_style_local_line_width(scr3_arc2,LV_ARC_PART_INDIC,LV_STATE_DEFAULT,60);         /* ���û��λ����� */
    lv_obj_set_style_local_line_color(scr3_arc2,LV_ARC_PART_INDIC,LV_STATE_DEFAULT,lv_color_make(128, 128,128));

    lv_obj_set_size(scr3_arc2 , 120, 120);
    lv_obj_align(scr3_arc2 , show_scr3, LV_ALIGN_CENTER, 0, 0);

    /* ����4 */
    // ���λ���ʽ�����ڻ��λ���
    static lv_style_t scr4_arc_style;
    lv_style_init(&scr4_arc_style);
    lv_style_set_line_width(&scr4_arc_style, LV_STATE_DEFAULT,50);         /* ���û��λ����� */
    lv_style_set_line_rounded(&scr4_arc_style, LV_STATE_DEFAULT,false);    /* ��������Ϊֱ�� */
    lv_style_set_pad_all(&scr4_arc_style, LV_STATE_DEFAULT,0);             /* �����ڲ������ ������ʾ���������֮��ľ��� */

    lv_style_set_line_color(&scr4_arc_style,LV_STATE_DEFAULT,MAIN_COLOR);  /* ���� ������ʾ������ɫ */
    lv_style_set_bg_opa(&scr4_arc_style,LV_STATE_DEFAULT,0);               /* ������ʾ����͸�� */
    lv_style_set_border_opa(&scr4_arc_style,LV_STATE_DEFAULT,0);               /* ������ʾ����͸�� */


    show_scr4 = lv_obj_create(NULL, NULL);            /* �ӵڶ������濪ʼ�������´�����Ļ�����ɴӵ�ǰ��Ļ�̳� */

    lv_obj_t * scr4_backgroud = lv_obj_create(show_scr4, NULL);     /* �������� ͬһ�ؼ��ǿ��Թ��õ�,Ҳ�������´���,���������ڴ�*/
    lv_obj_set_style_local_bg_color(scr4_backgroud,LV_OBJ_PART_MAIN,LV_STATE_DEFAULT,lv_color_make(1, 1,1));  /* ���ñ���������ɫ����ɫ */
    lv_obj_set_style_local_border_color(scr4_backgroud,LV_OBJ_PART_MAIN,LV_STATE_DEFAULT,lv_color_make(1,1,1));
    lv_obj_set_size(scr4_backgroud, 240,240);
    lv_obj_align(scr3_backgroud, show_scr4, LV_ALIGN_CENTER, 0, 0);

    lv_obj_t *scr4_arc = lv_arc_create(show_scr4,NULL);
    lv_obj_add_style(scr4_arc  ,LV_ARC_PART_INDIC, &scr4_arc_style);         /* ���û�����ʾ������ʽ  */
    lv_obj_add_style(scr4_arc  ,LV_ARC_PART_BG, &scr4_arc_style);            /* ���ñ���������ʽ*/
    lv_obj_set_style_local_line_opa(scr4_arc,LV_ARC_PART_INDIC,LV_STATE_DEFAULT,100);
    lv_obj_set_style_local_line_color(scr4_arc,LV_ARC_PART_INDIC,LV_STATE_DEFAULT,lv_color_make(128, 128,128));

    lv_arc_set_bg_angles(scr4_arc ,0,0);
    lv_arc_set_angles(scr4_arc , 0,360);
    lv_obj_set_size(scr4_arc , 100, 100);
    lv_obj_align(scr4_arc , show_scr4, LV_ALIGN_CENTER, 0, 0);

  //lv_scr_load_anim(scr15, LV_SCR_LOAD_ANIM_NONE, 1000, 500, false);
}
/**********************
 *   GLOBAL FUNCTIONS
 **********************/
uint32_t cnt_old = 0;
#if WIN32
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR szCmdLine, int nCmdShow)
#else
int main(int argc, char** argv)

#endif // WIN32
{
    /*Initialize LittlevGL*/
    lv_init();

    /*Initialize the HAL for LittlevGL*/
    hal_init();

    /*Check the themes too*/
    //lv_disp_set_default(lv_windows_disp);

    /*Run the v7 demo*/
    //lv_demo_widgets();
    //screen2_init();
    //screen1_init();
    test_screen();
    fps_cnt = lv_tick_get();
    cnt_old =  lv_tick_get();
    //lv_ex_style_11();
    //lv_ex_arc_2();
   //lv_ex_img_5();
   //lv_ex_style_10();
#if WIN32
    while(!lv_win_exit_flag) {
#else
    while(1) {
#endif // WIN32
        /* Periodically call the lv_task handler.
         * It could be done in a timer interrupt or an OS task too.*/
      if(lv_tick_get()> cnt_old+16000){
            cnt_old =  lv_tick_get();
            scr1_task_flag = true;
            rest_show_scr1();
            lv_scr_load(show_scr1);
        }
        else if(lv_tick_get()> cnt_old+12000){
            //lv_scr_load(scr11);
            //scr11 = lv_obj_create(NULL, NULL);
            //scr1_task_flag = false;
            lv_scr_load(show_scr4);
            //lv_task_del(scr1_task );
            //lv_scr_load_anim(scr11, LV_SCR_LOAD_ANIM_NONE, 1, 1, 0);
        }
       else if(lv_tick_get()> cnt_old+8000){
            //lv_scr_load(scr11);
            //scr11 = lv_obj_create(NULL, NULL);
            //scr1_task_flag = false;
            lv_scr_load(show_scr3);
            //lv_task_del(scr1_task );
            //lv_scr_load_anim(scr11, LV_SCR_LOAD_ANIM_NONE, 1, 1, 0);
        }
        else if(lv_tick_get()> cnt_old+4000){
            //lv_scr_load(scr11);
            //scr11 = lv_obj_create(NULL, NULL);
            //scr1_task_flag = false;
            lv_scr_load(show_scr2);
            //lv_task_del(scr1_task );
            //lv_scr_load_anim(scr11, LV_SCR_LOAD_ANIM_NONE, 1, 1, 0);
        }

        lv_task_handler();
        usleep(1000);       /*Just to let the system breath*/
    }
    return 0;
}

/**********************
 *   STATIC FUNCTIONS
 **********************/

/**
 * Initialize the Hardware Abstraction Layer (HAL) for the Littlev graphics library
 */
static void hal_init(void)
{
#if !WIN32
    /* Add a display
     * Use the 'monitor' driver which creates window on PC's monitor to simulate a display*/
    monitor_init();
    lv_disp_drv_t disp_drv;
    lv_disp_drv_init(&disp_drv);            /*Basic initialization*/
    disp_drv.disp_flush = monitor_flush;
    disp_drv.disp_fill = monitor_fill;
    disp_drv.disp_map = monitor_map;
    lv_disp_drv_register(&disp_drv);

    /* Add the mouse (or touchpad) as input device
     * Use the 'mouse' driver which reads the PC's mouse*/
    mouse_init();
    lv_indev_drv_t indev_drv;
    lv_indev_drv_init(&indev_drv);          /*Basic initialization*/
    indev_drv.type = LV_INDEV_TYPE_POINTER;
    indev_drv.read = mouse_read;         /*This function will be called periodically (by the library) to get the mouse position and state*/
    lv_indev_drv_register(&indev_drv);

    /* Tick init.
     * You have to call 'lv_tick_handler()' in every milliseconds
     * Create an SDL thread to do this*/
    SDL_CreateThread(tick_thread, "tick", NULL);
#else
    /* This sets up some timers to handle everything. */
    windrv_init();
#endif
}
#if !WIN32
/**
 * A task to measure the elapsed time for LittlevGL
 * @param data unused
 * @return never return
 */
static int tick_thread(void *data)
{
    while(1) {
        lv_tick_inc(1);
        SDL_Delay(1);   /*Sleep for 1 millisecond*/
    }

    return 0;
}
#endif
