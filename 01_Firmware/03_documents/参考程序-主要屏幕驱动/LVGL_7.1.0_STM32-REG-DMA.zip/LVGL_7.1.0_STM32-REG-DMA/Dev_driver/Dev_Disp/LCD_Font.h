#ifndef __LCD_font_
#define __LCD_font_

extern const unsigned char LCD_asc2_2412[95][36];



#endif
