#ifndef _font_h_
#define _font_h_

extern const unsigned char img1[1024];
extern const unsigned char img2[1024];
extern const unsigned char asc2_1206[95][12];
extern const unsigned char asc2_1608[95][16];
extern const unsigned char asc2_2412[95][36];

#endif
