# LVGL For STM32
- Blank_Temp分支为移植前的工程
- demo_prj分支为移植后的工程
- master分支为后续开发主分支
- 博客教程
    - [【LVGL学习之旅 01】移植LVGL到STM32](https://blog.csdn.net/qq_40831286/article/details/107633216)