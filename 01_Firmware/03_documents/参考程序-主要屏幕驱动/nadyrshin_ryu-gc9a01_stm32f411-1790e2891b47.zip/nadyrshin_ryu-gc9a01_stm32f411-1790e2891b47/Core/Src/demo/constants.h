#ifndef SRC_DEMO_CONSTANTS_H_
#define SRC_DEMO_CONSTANTS_H_


#define PI 	3.14159265
#define xC	120
#define yC	120

#endif /* SRC_DEMO_CONSTANTS_H_ */
