#ifndef _F32F_H
#define _F32F_H

#define f32_FLOAT_HEIGHT        32

#define f32f_NOFCHARS           10

uint8_t *f32f_GetCharTable(char Char);

#endif 
