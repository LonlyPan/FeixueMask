#ifndef _F24F_H
#define _F24F_H

#define f24_FLOAT_HEIGHT        24

#define f24f_NOFCHARS           10

uint8_t *f24f_GetCharTable(char Char);

#endif 
