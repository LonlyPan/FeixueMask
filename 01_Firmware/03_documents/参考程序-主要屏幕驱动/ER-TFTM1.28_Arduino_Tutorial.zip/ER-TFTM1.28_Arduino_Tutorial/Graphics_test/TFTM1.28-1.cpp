/*************************************************** 
  www.buydisplay.com
 ****************************************************/

#include "TFTM1.28-1.h"
#include <avr/pgmspace.h>
#include <limits.h>
#include "pins_arduino.h"
#include "wiring_private.h"
#include <SPI.h>

// Constructor when using software SPI.  All output pins are configurable.
GC9A01::GC9A01(int8_t cs, int8_t dc, int8_t mosi,
				   int8_t sclk, int8_t rst) : ERGFX(GC9A01_TFTWIDTH, GC9A01_TFTHEIGHT) {
  _cs   = cs;
  _dc   = dc;
  _mosi  = mosi;
  _sclk = sclk;
  _rst  = rst;
  hwSPI = false;
}


// Constructor when using hardware SPI.  Faster, but must use SPI pins
// specific to each board type (e.g. 11,13 for Uno, 51,52 for Mega, etc.)
GC9A01::GC9A01(int8_t cs, int8_t dc, int8_t rst) : ERGFX(GC9A01_TFTWIDTH, GC9A01_TFTHEIGHT) {
  _cs   = cs;
  _dc   = dc;
  _rst  = rst;
  hwSPI = true;
  _mosi  = _sclk = 0;
}

void GC9A01::spiwrite(uint8_t c) {

  //Serial.print("0x"); Serial.print(c, HEX); Serial.print(", ");

  if (hwSPI) {
#if defined (__AVR__)
      uint8_t backupSPCR = SPCR;
    SPCR = mySPCR;
    SPDR = c;
    while(!(SPSR & _BV(SPIF)));
    SPCR = backupSPCR;
#elif defined(TEENSYDUINO)
    SPI.transfer(c);
#elif defined (__arm__)
    SPI.setClockDivider(11); // 8-ish MHz (full! speed!)
    SPI.setBitOrder(MSBFIRST);
    SPI.setDataMode(SPI_MODE0);
    SPI.transfer(c);
#endif
  } else {
    // Fast SPI bitbang swiped from LPD8806 library
    for(uint8_t bit = 0x80; bit; bit >>= 1) {
      if(c & bit) {
	//digitalWrite(_mosi, HIGH); 
	*mosiport |=  mosipinmask;
      } else {
	//digitalWrite(_mosi, LOW); 
	*mosiport &= ~mosipinmask;
      }
      //digitalWrite(_sclk, LOW);
      *clkport &= ~clkpinmask;
       //digitalWrite(_sclk, HIGH);
      *clkport |=  clkpinmask;
    }
  }
}


void GC9A01::writecommand(uint8_t c) {
  *dcport &=  ~dcpinmask;
  //digitalWrite(_dc, LOW);
  //*clkport &= ~clkpinmask; // clkport is a NULL pointer when hwSPI==true
  //digitalWrite(_sclk, LOW);
  *csport &= ~cspinmask;
  //digitalWrite(_cs, LOW);

  spiwrite(c);

  *csport |= cspinmask;
  //digitalWrite(_cs, HIGH);
}


void GC9A01::writedata(uint8_t c) {
  *dcport |=  dcpinmask;
  //digitalWrite(_dc, HIGH);
  //*clkport &= ~clkpinmask; // clkport is a NULL pointer when hwSPI==true
  //digitalWrite(_sclk, LOW);
  *csport &= ~cspinmask;
  //digitalWrite(_cs, LOW);
  
  spiwrite(c);

  //digitalWrite(_cs, HIGH);
  *csport |= cspinmask;
} 

// If the SPI library has transaction support, these functions
// establish settings and protect from interference from other
// libraries.  Otherwise, they simply do nothing.
#ifdef SPI_HAS_TRANSACTION
static inline void spi_begin(void) __attribute__((always_inline));
static inline void spi_begin(void) {
  SPI.beginTransaction(SPISettings(8000000, MSBFIRST, SPI_MODE0));
}
static inline void spi_end(void) __attribute__((always_inline));
static inline void spi_end(void) {
  SPI.endTransaction();
}
#else
#define spi_begin()
#define spi_end()
#endif


void GC9A01::begin(void) {
  if (_rst > 0) {
    pinMode(_rst, OUTPUT);
    digitalWrite(_rst, LOW);
  }

  pinMode(_dc, OUTPUT);
  pinMode(_cs, OUTPUT);
  
  csport    = portOutputRegister(digitalPinToPort(_cs));
  cspinmask = digitalPinToBitMask(_cs);
  dcport    = portOutputRegister(digitalPinToPort(_dc));
  dcpinmask = digitalPinToBitMask(_dc);

  if(hwSPI) { // Using hardware SPI
#if defined (__AVR__)
    SPI.begin();
    SPI.setClockDivider(SPI_CLOCK_DIV2); // 8 MHz (full! speed!)
    SPI.setBitOrder(MSBFIRST);
    SPI.setDataMode(SPI_MODE0);
    mySPCR = SPCR;
#elif defined(TEENSYDUINO)
    SPI.begin();
    SPI.setClockDivider(SPI_CLOCK_DIV2); // 8 MHz (full! speed!)
    SPI.setBitOrder(MSBFIRST);
    SPI.setDataMode(SPI_MODE0);
#elif defined (__arm__)
      SPI.begin();
      SPI.setClockDivider(11); // 8-ish MHz (full! speed!)
      SPI.setBitOrder(MSBFIRST);
      SPI.setDataMode(SPI_MODE0);
#endif
  } else {
    pinMode(_sclk, OUTPUT);
    pinMode(_mosi, OUTPUT);

    clkport     = portOutputRegister(digitalPinToPort(_sclk));
    clkpinmask  = digitalPinToBitMask(_sclk);
    mosiport    = portOutputRegister(digitalPinToPort(_mosi));
    mosipinmask = digitalPinToBitMask(_mosi);
    *clkport   &= ~clkpinmask;
    *mosiport  &= ~mosipinmask;
  }

  // toggle RST low to reset
  if (_rst > 0) {
    digitalWrite(_rst, HIGH);
    delay(5);
    digitalWrite(_rst, LOW);
    delay(20);
    digitalWrite(_rst, HIGH);
    delay(150);
  }

  if (hwSPI) spi_begin();
  
  
	 //************* Start Initial Sequence **********// 
	writecommand(0xEF);
 
	writecommand(0xEB);
	writedata(0x14); 
	
    writecommand(0xFE);			 
	writecommand(0xEF); 

	writecommand(0xEB);	
	writedata(0x14); 

	writecommand(0x84);			
	writedata(0x40); 

	writecommand(0x85);			
	writedata(0xFF); 

	writecommand(0x86);			
	writedata(0xFF); 

	writecommand(0x87);			
	writedata(0xFF);

	writecommand(0x88);			
	writedata(0x0A);

	writecommand(0x89);			
	writedata(0x21); 

	writecommand(0x8A);			
	writedata(0x00); 

	writecommand(0x8B);			
	writedata(0x80); 

	writecommand(0x8C);			
	writedata(0x01); 

	writecommand(0x8D);			
	writedata(0x01); 

	writecommand(0x8E);			
	writedata(0xFF); 

	writecommand(0x8F);			
	writedata(0xFF); 


	writecommand(0xB6);
	writedata(0x00); 			
	writedata(0x00); 

	writecommand(0x36);
	
	if(USE_HORIZONTAL==0)writedata(0x18);
	else if(USE_HORIZONTAL==1)writedata(0x28);
	else if(USE_HORIZONTAL==2)writedata(0x48);
	else writedata(0x88);
  


	writecommand(0x3A);			
	writedata(0x05); 


	writecommand(0x90);			
	writedata(0x08);
	writedata(0x08);
	writedata(0x08);
	writedata(0x08); 

	writecommand(0xBD);			
	writedata(0x06);
	
	writecommand(0xBC);			
	writedata(0x00);	

	writecommand(0xFF);			
	writedata(0x60);
	writedata(0x01);
	writedata(0x04);

	writecommand(0xC3);			
	writedata(0x13);
	writecommand(0xC4);			
	writedata(0x13);

	writecommand(0xC9);			
	writedata(0x22);

	writecommand(0xBE);			
	writedata(0x11); 

	writecommand(0xE1);			
	writedata(0x10);
	writedata(0x0E);

	writecommand(0xDF);			
	writedata(0x21);
	writedata(0x0c);
	writedata(0x02);

	writecommand(0xF0);   
    writedata(0x45);
    writedata(0x09);
 	writedata(0x08);
  	writedata(0x08);
 	writedata(0x26);
 	writedata(0x2A);

 	writecommand(0xF1);    
 	writedata(0x43);
 	writedata(0x70);
 	writedata(0x72);
 	writedata(0x36);
 	writedata(0x37);  
 	writedata(0x6F);


 	writecommand(0xF2);   
 	writedata(0x45);
 	writedata(0x09);
 	writedata(0x08);
 	writedata(0x08);
 	writedata(0x26);
 	writedata(0x2A);

 	writecommand(0xF3);   
 	writedata(0x43);
 	writedata(0x70);
 	writedata(0x72);
 	writedata(0x36);
 	writedata(0x37); 
 	writedata(0x6F);

	writecommand(0xED);	
	writedata(0x1B); 
	writedata(0x0B); 

	writecommand(0xAE);			
	writedata(0x77);
	
	writecommand(0xCD);			
	writedata(0x63);		


	writecommand(0x70);			
	writedata(0x07);
	writedata(0x07);
	writedata(0x04);
	writedata(0x0E); 
	writedata(0x0F); 
	writedata(0x09);
	writedata(0x07);
	writedata(0x08);
	writedata(0x03);

	writecommand(0xE8);			
	writedata(0x34);

	writecommand(0x62);			
	writedata(0x18);
	writedata(0x0D);
	writedata(0x71);
	writedata(0xED);
	writedata(0x70); 
	writedata(0x70);
	writedata(0x18);
	writedata(0x0F);
	writedata(0x71);
	writedata(0xEF);
	writedata(0x70); 
	writedata(0x70);

	writecommand(0x63);			
	writedata(0x18);
	writedata(0x11);
	writedata(0x71);
	writedata(0xF1);
	writedata(0x70); 
	writedata(0x70);
	writedata(0x18);
	writedata(0x13);
	writedata(0x71);
	writedata(0xF3);
	writedata(0x70); 
	writedata(0x70);

	writecommand(0x64);			
	writedata(0x28);
	writedata(0x29);
	writedata(0xF1);
	writedata(0x01);
	writedata(0xF1);
	writedata(0x00);
	writedata(0x07);

	writecommand(0x66);			
	writedata(0x3C);
	writedata(0x00);
	writedata(0xCD);
	writedata(0x67);
	writedata(0x45);
	writedata(0x45);
	writedata(0x10);
	writedata(0x00);
	writedata(0x00);
	writedata(0x00);

	writecommand(0x67);			
	writedata(0x00);
	writedata(0x3C);
	writedata(0x00);
	writedata(0x00);
	writedata(0x00);
	writedata(0x01);
	writedata(0x54);
	writedata(0x10);
	writedata(0x32);
	writedata(0x98);

	writecommand(0x74);			
	writedata(0x10);	
	writedata(0x85);	
	writedata(0x80);
	writedata(0x00); 
	writedata(0x00); 
	writedata(0x4E);
	writedata(0x00);					
	
        writecommand(0x98);			
	writedata(0x3e);
	writedata(0x07);

	writecommand(0x35);	
	writecommand(0x21);
 
	

        writecommand(0x11);    //Exit Sleep 
        if (hwSPI) spi_end();
        delay(120); 		
        if (hwSPI) spi_begin();
        writecommand(0x29);    //Display on 
        if (hwSPI) spi_end();

}


void GC9A01::setAddrWindow(uint16_t x0, uint16_t y0, uint16_t x1,
 uint16_t y1) {

  writecommand(GC9A01_CASET); // Column addr set
  writedata(x0 >> 8);
  writedata(x0 & 0xFF);     // XSTART 
  writedata(x1 >> 8);
  writedata(x1 & 0xFF);     // XEND

  writecommand(GC9A01_PASET); // Row addr set
  writedata(y0>>8);
  writedata(y0);     // YSTART
  writedata(y1>>8);
  writedata(y1);     // YEND

  writecommand(GC9A01_RAMWR); // write to RAM
}


void GC9A01::pushColor(uint16_t color) {
  if (hwSPI) spi_begin();
  //digitalWrite(_dc, HIGH);
  *dcport |=  dcpinmask;
  //digitalWrite(_cs, LOW);
  *csport &= ~cspinmask;

  spiwrite(color >> 8);
  spiwrite(color);

  *csport |= cspinmask;
  //digitalWrite(_cs, HIGH);
  if (hwSPI) spi_end();
}

void GC9A01::drawPixel(int16_t x, int16_t y, uint16_t color) {

  if((x < 0) ||(x >= _width) || (y < 0) || (y >= _height)) return;

  if (hwSPI) spi_begin();
  setAddrWindow(x,y,x+1,y+1);

  //digitalWrite(_dc, HIGH);
  *dcport |=  dcpinmask;
  //digitalWrite(_cs, LOW);
  *csport &= ~cspinmask;

  spiwrite(color >> 8);
  spiwrite(color);

  *csport |= cspinmask;
  //digitalWrite(_cs, HIGH);
  if (hwSPI) spi_end();
}


void GC9A01::drawFastVLine(int16_t x, int16_t y, int16_t h,
 uint16_t color) {

  // Rudimentary clipping
  if((x >= _width) || (y >= _height)) return;

  if((y+h-1) >= _height) 
    h = _height-y;

  if (hwSPI) spi_begin();
  setAddrWindow(x, y, x, y+h-1);

  uint8_t hi = color >> 8, lo = color;

  *dcport |=  dcpinmask;
  //digitalWrite(_dc, HIGH);
  *csport &= ~cspinmask;
  //digitalWrite(_cs, LOW);

  while (h--) {
    spiwrite(hi);
    spiwrite(lo);
  }
  *csport |= cspinmask;
  //digitalWrite(_cs, HIGH);
  if (hwSPI) spi_end();
}


void GC9A01::drawFastHLine(int16_t x, int16_t y, int16_t w,
  uint16_t color) {

  // Rudimentary clipping
  if((x >= _width) || (y >= _height)) return;
  if((x+w-1) >= _width)  w = _width-x;
  if (hwSPI) spi_begin();
  setAddrWindow(x, y, x+w-1, y);

  uint8_t hi = color >> 8, lo = color;
  *dcport |=  dcpinmask;
  *csport &= ~cspinmask;
  //digitalWrite(_dc, HIGH);
  //digitalWrite(_cs, LOW);
  while (w--) {
    spiwrite(hi);
    spiwrite(lo);
  }
  *csport |= cspinmask;
  //digitalWrite(_cs, HIGH);
  if (hwSPI) spi_end();
}

void GC9A01::fillScreen(uint16_t color) {
  fillRect(0, 0,  _width, _height, color);
}

// fill a rectangle
void GC9A01::fillRect(int16_t x, int16_t y, int16_t w, int16_t h,
  uint16_t color) {

  // rudimentary clipping (drawChar w/big text requires this)
  if((x >= _width) || (y >= _height)) return;
  if((x + w - 1) >= _width)  w = _width  - x;
  if((y + h - 1) >= _height) h = _height - y;

  if (hwSPI) spi_begin();
  setAddrWindow(x, y, x+w-1, y+h-1);

  uint8_t hi = color >> 8, lo = color;

  *dcport |=  dcpinmask;
  //digitalWrite(_dc, HIGH);
  *csport &= ~cspinmask;
  //digitalWrite(_cs, LOW);

  for(y=h; y>0; y--) {
    for(x=w; x>0; x--) {
      spiwrite(hi);
      spiwrite(lo);
    }
  }
  //digitalWrite(_cs, HIGH);
  *csport |= cspinmask;
  if (hwSPI) spi_end();
}


// Pass 8-bit (each) R,G,B, get back 16-bit packed color
uint16_t GC9A01::color565(uint8_t r, uint8_t g, uint8_t b) {
  return ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3);
}

 

