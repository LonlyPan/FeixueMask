/*
 * main.h
 *
 *  Created on: Dec 10, 2020
 *      Author: 23714
 */

#ifndef FEIXUE_H_
#define FEIXUE_H_

#include "common.h"


void setup();
void loop();


#endif /* FEIXUE_H_ */
