/*
 * img_array.h
 *
 *  Created on: Dec 16, 2020
 *      Author: 23714
 */

#ifndef IMG_ARRAY_H_
#define IMG_ARRAY_H_

extern const lv_img_dsc_t  bilibili;
extern const lv_img_dsc_t  bilibili2;
#endif /* IMG_ARRAY_H_ */
