/*
 * speech_usart.c
 *
 *  Created on: Dec 17, 2020
 *      Author: 23714
 */

#ifndef SPEECH_USART_C_
#define SPEECH_USART_C_
#include "speech_usart.h"

uint8_t RxBuffer;
uint8_t RxCommand[4] = {0,0,0,0};
uint8_t RxBufferLength = 0;
uint8_t current_command = 0;

uint8_t command_flag = 0;

unsigned char wake_up_array[4] = {0xF4,0x0A,0x01,0xFF}; // 唤醒

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *UartHandle)
{
	if(UartHandle->Instance == USART1){   //判断时那种中断
		RxCommand[RxBufferLength++] = RxBuffer;
		if(RxCommand[0] == 0xF4){
			if(RxBufferLength == 4){
				if(RxCommand[1] == 0x06 && RxCommand[3] == 0xFF){
					current_command = RxCommand[2];
				}
				else{
					current_command = 0;
				}

				RxBufferLength = 0;
				for(int i = 0;i<4;i++){
					RxCommand[i] = 0x00;
				}
			}
		}
		else
			RxBufferLength = 0;
		//HAL_UART_Transmit(&huart1,(uint8_t *)RxBuffer,1,10);  // 发送10个数据
	}
	HAL_UART_Receive_IT(&huart1,&RxBuffer,1); // 再次开启中断
}

void speeech_wake_up(){
	HAL_UART_Transmit(&huart1, wake_up_array, sizeof(wake_up_array), 500);
}

#endif /* SPEECH_USART_C_ */
