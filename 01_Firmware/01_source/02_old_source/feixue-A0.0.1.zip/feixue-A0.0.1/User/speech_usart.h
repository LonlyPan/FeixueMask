/*
 * speech_usart.h
 *
 *  Created on: Dec 17, 2020
 *      Author: 23714
 */

#ifndef SPEECH_USART_H_
#define SPEECH_USART_H_

#include "usart.h"

extern uint8_t RxBuffer;  // 定义一个接受数组
extern uint8_t current_command;
/* 语音内容索引 */
enum VOICE_CONTENT{
    SPEECH_WAKE_UP = 1,      // 唤醒
	SPEECH_LIGHT_ON,
	SPEECH_LIGHT_OFF,
	SPEECH_FANS_ONE_GEAR = 10,
	SPEECH_FANS_TWO_GEAR,
	SPEECH_FANS_THREE_GEAR,
	SPEECH_FANS_FOUR_GEAR,
	SPEECH_PREVIOUS_PIECE = 33,
	SPEECH_NEXT_PIECE = 34,
	IDENTIFY_COMMAND2,
	IDENTIFY_COMMAND3,
	IDENTIFY_COMMAND4,
	IDENTIFY_COMMAND5,
	IDENTIFY_COMMAND6,
	IDENTIFY_COMMAND7,
	IDENTIFY_COMMAND8,
	IDENTIFY_COMMAND9,
	IDENTIFY_COMMAND10,
};


void speeech_wake_up();


#endif /* SPEECH_USART_H_ */
