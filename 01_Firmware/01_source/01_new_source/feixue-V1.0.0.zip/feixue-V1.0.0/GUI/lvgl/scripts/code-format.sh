astyle --options=code-format.cfg "../src/*.c,*.h"
