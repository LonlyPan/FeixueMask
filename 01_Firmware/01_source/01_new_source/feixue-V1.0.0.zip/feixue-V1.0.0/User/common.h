/*
 * common.h
 *
 *  Created on: Dec 10, 2020
 *      Author: 23714
 */

#ifndef COMMON_H_
#define COMMON_H_

#include "macros.h"
#include "cc.h"

#endif /* COMMON_H_ */
