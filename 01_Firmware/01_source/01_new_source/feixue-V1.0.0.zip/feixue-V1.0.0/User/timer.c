/*
 * timer.c
 *
 *  Created on: Dec 10, 2020
 *      Author: 23714
 */
#include "timer.h"
#include "lvgl.h"
/* 中断回调函数 */

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	lv_tick_inc(1);//lvgl的1ms心跳
	fps_cnt++;
}
