/*
 * timer.h
 *
 *  Created on: Dec 10, 2020
 *      Author: 23714
 */

#ifndef TIMER_H_
#define TIMER_H_
#include "common.h"
#include "tim.h"
volatile u32 fps_cnt;
#endif /* TIMER_H_ */
