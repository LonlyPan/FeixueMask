/*
 * macros.h
 *
 *  Created on: Dec 17, 2020
 *      Author: 23714
 */

#ifndef MACROS_H_
#define MACROS_H_

#include "stm32f4xx_hal.h"

#define millis() HAL_GetTick()
/* 专门用于 millis() 型变量声明 */
typedef unsigned long millis_t;


#define PI (3.14159265358979323846)


#define min(a,b) ((a)<(b)?(a):(b))
#define max(a,b) ((a)>(b)?(a):(b))

#define constrain(amt,low,high) ((amt)<(low)?(low):((amt)>(high)?(high):(amt)))

#define PENDING(NOW,SOON) ((long)(NOW-(SOON))<0)
#define ELAPSED(NOW,SOON) (!PENDING(NOW,SOON))  /* NOW > SOON return true */

#define FABS(x)     fabs(x)
#endif /* MACROS_H_ */
